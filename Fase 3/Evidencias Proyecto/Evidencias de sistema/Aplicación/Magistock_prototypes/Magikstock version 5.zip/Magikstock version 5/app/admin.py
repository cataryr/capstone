from django.contrib import admin
from .models import Profile, Sucursal

admin.site.register(Profile)
admin.site.register(Sucursal) 
